package com.example.demo02.controller;

import com.example.demo02.entity.User;
import com.example.demo02.service.IUserService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.List;

@Controller
@RequestMapping("user")
public class UserController {

    @Resource(name = "userService")
    public IUserService userService;

    @RequestMapping("findDs1AllUser")
    @ResponseBody
    public List<User> findDs1AllUser(){
        List<User> user = this.userService.findDs1AllUser();
        return user;
    }

    @RequestMapping("findDs2AllUser")
    @ResponseBody
    public List<User> findDs2AllUser(){
        List<User> user = this.userService.findDs2AllUser();
        return user;
    }
}
