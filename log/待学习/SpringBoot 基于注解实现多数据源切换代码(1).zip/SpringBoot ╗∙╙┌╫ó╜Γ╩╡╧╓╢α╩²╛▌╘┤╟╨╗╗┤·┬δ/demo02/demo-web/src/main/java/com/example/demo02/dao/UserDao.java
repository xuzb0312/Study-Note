package com.example.demo02.dao;

import com.example.demo02.entity.User;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("userDao")
public interface UserDao{

    List<User> findDs1AllUser();

    List<User> findDs2AllUser();

    void insertUserToDs1(User user);
}
