package com.example.demo02.service.impl;

import com.example.demo02.annotation.Ds;
import com.example.demo02.dao.UserDao;
import com.example.demo02.entity.User;
import com.example.demo02.service.IUserService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.List;

@Service("userService")
public class UserServiceImpl implements IUserService {

    @Resource(name = "userDao")
    public UserDao userDao;

    @Override
    @Ds("ds1")
    @Transactional
    public List<User> findDs1AllUser() {

//        User user1 = new User();
//        user1.setId("123");
//        user1.setName("B");
//        user1.setAge("56");
//        user1.setAddress("北京市");
//        userDao.insertUserToDs1(user1);

        List<User> users = userDao.findDs1AllUser();
        return users;
    }

    @Override
    @Ds("ds2")
    public List<User> findDs2AllUser() {
        List<User> user = userDao.findDs2AllUser();
        return user;
    }


}
