package com.example.demo02.service;

import com.example.demo02.entity.User;

import java.util.List;

public interface IUserService {

    List<User> findDs1AllUser();

    List<User> findDs2AllUser();

}
